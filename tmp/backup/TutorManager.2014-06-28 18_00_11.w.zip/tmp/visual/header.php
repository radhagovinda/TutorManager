<STYLE type=text/css>
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-image: url(images/bg-gray.png);
}
.style1 {
	font-size: 24px;
	font-weight: bold;
	font-family: Georgia, "Times New Roman", Times, serif;
	color: #FFFFFF;
}
.style2 {
	font-size: 16px;
	font-style: italic;
}
.style3 {
	font-size: 36px;
	font-family: Verdana, Arial, Helvetica, sans-serif;
}
-->
</STYLE>
<TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
  <TBODY>
  <TR>
    <TD height=10 background=images/header-w.png><IMG alt="" src="" width=32 
      height=10></TD></TR>
  <TR>
    <TD background=images/bg.png>
      <TABLE cellSpacing=5 cellPadding=10 width="100%" border=0>
        <TBODY>
        <TR>
          <TD height=100><SPAN class=style1><SPAN class=style3><IMG alt="" 
            src="" width=50 height=32>Tuition Manager</SPAN><BR><SPAN 
            class=style2><SPAN class=style3><IMG alt="" src="" width=50 
            height=32></SPAN>Manage your students/Attendance/Exams more 
            efficiently</SPAN></SPAN></TD></TR>
        <TR>
          <TD><A href="menu.php"><SPAN class=style3><IMG alt="" src="" 
            width=50 
            height=32></SPAN><IMG 
            border=0 src="images/home-65.png" width=68 
            height=64></A></TD></TR></TBODY></TABLE></TD></TR>
  <TR>
    <TD height=10 background=images/header-w.png><IMG alt="" src="" width=32 
      height=10></TD></TR></TBODY></TABLE>